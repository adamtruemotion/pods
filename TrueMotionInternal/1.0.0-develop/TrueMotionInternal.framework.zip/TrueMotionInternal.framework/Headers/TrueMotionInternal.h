//
//  TrueMotionInternal.h
//  TrueMotionInternal
//
//  Created by Adam Horvath on 2020. 08. 24..
//  Copyright © 2020. TrueMotion. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TrueMotionInternal.
FOUNDATION_EXPORT double TrueMotionInternalVersionNumber;

//! Project version string for TrueMotionInternal.
FOUNDATION_EXPORT const unsigned char TrueMotionInternalVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TrueMotionInternal/PublicHeader.h>


